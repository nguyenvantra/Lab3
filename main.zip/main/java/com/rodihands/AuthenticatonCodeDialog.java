package com.rodihands;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import java.util.ArrayList;
import java.util.List;

public class AuthenticatonCodeDialog extends DialogFragment implements View.OnClickListener {
    private Button btnPin0;
    private Button btnPin1;
    private Button btnPin2;
    private Button btnPin3;
    private Button btnPin4;
    private Button btnPin5;
    private Button btnPin6;
    private Button btnPin7;
    private Button btnPin8;
    private Button btnPin9;
    private Button btnPinClear;
    private Button btnPinDelete;
    private ImageView ivPinNum1;
    private ImageView ivPinNum2;
    private ImageView ivPinNum3;
    private ImageView ivPinNum4;

    public AuthenticatonCodeDialog() {
    }

    public static AuthenticatonCodeDialog newInstance() {
        AuthenticatonCodeDialog authenticatonCodeDialog = new AuthenticatonCodeDialog();
        return authenticatonCodeDialog;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        // The content
        final RelativeLayout root = new RelativeLayout(getActivity());
        root.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // Creating the fullscreen dialog
        final Dialog dialog = new Dialog(getActivity());
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(root);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.WHITE));
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);

        return dialog;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView(view);
    }

    private void initView(View view) {
        btnPin0 = view.findViewById(R.id.btn_pin_0);
        btnPin1 = view.findViewById(R.id.btn_pin_1);
        btnPin2 = view.findViewById(R.id.btn_pin_2);
        btnPin3 = view.findViewById(R.id.btn_pin_3);
        btnPin4 = view.findViewById(R.id.btn_pin_4);
        btnPin5 = view.findViewById(R.id.btn_pin_5);
        btnPin6 = view.findViewById(R.id.btn_pin_6);
        btnPin7 = view.findViewById(R.id.btn_pin_7);
        btnPin8 = view.findViewById(R.id.btn_pin_8);
        btnPin9 = view.findViewById(R.id.btn_pin_9);
        btnPinClear = view.findViewById(R.id.btn_pin_clear);
        btnPinDelete = view.findViewById(R.id.btn_pin_delete);
        ivPinNum1 = view.findViewById(R.id.iv_pin_num_1);
        ivPinNum2 = view.findViewById(R.id.iv_pin_num_2);
        ivPinNum3 = view.findViewById(R.id.iv_pin_num_3);
        ivPinNum4 = view.findViewById(R.id.iv_pin_num_4);

        btnPin0.setOnClickListener(this);
        btnPin1.setOnClickListener(this);
        btnPin2.setOnClickListener(this);
        btnPin3.setOnClickListener(this);
        btnPin4.setOnClickListener(this);
        btnPin5.setOnClickListener(this);
        btnPin6.setOnClickListener(this);
        btnPin7.setOnClickListener(this);
        btnPin8.setOnClickListener(this);
        btnPin9.setOnClickListener(this);
        btnPinClear.setOnClickListener(this);
        btnPinDelete.setOnClickListener(this);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.authentication_code_dialog, container);
    }

    @Override
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if (dialog != null) {
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn_pin_0:
                break;
            case R.id.btn_pin_1:
                break;
            case R.id.btn_pin_2:
                break;
            case R.id.btn_pin_3:
                break;
            case R.id.btn_pin_4:
                break;
            case R.id.btn_pin_5:
                break;
            case R.id.btn_pin_6:
                break;
            case R.id.btn_pin_7:
                break;
            case R.id.btn_pin_8:
                break;
            case R.id.btn_pin_9:
                break;
            case R.id.btn_pin_clear:
                break;
            case R.id.btn_pin_delete:
                break;
            default:
                break;
        }
    }

//    private void handleOnClick(int value) {
//        if (pins.size() < 4) {
//            pins.add(value);
//            if (pins.size() == 1) ivPinNum1.setVisibility(View.VISIBLE);
//            if (pins.size() == 2) ivPinNum2.setVisibility(View.VISIBLE);
//            if (pins.size() == 3) ivPinNum3.setVisibility(View.VISIBLE);
//            if (pins.size() == 4) ivPinNum4.setVisibility(View.VISIBLE);
//        }
//
//        if (pins.size() == 4) {
//            Log.d("RodiHands", pins.toString());
//        }
//    }
//
//    private void handleClear() {
//        pins.clear();
//        ivPinNum1.setVisibility(View.GONE);
//        ivPinNum2.setVisibility(View.GONE);
//        ivPinNum3.setVisibility(View.GONE);
//        ivPinNum4.setVisibility(View.GONE);
//    }
//
//    private void handleDelete() {
//        if (pins.size() >= 1) {
//            pins.remove(pins.size() - 1);
//            if (pins.size() == 0) ivPinNum1.setVisibility(View.GONE);
//            if (pins.size() == 1) ivPinNum2.setVisibility(View.GONE);
//            if (pins.size() == 2) ivPinNum3.setVisibility(View.GONE);
//            if (pins.size() == 3) ivPinNum4.setVisibility(View.GONE);
//        }
//    }
}
