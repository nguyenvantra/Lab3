package com.rodihands;

import java.util.List;

public class RodiHandPinValue {
    private List<Integer> pins;

    public RodiHandPinValue(List<Integer> pins) {
        this.pins = pins;
    }

    public List<Integer> getPins() {
        return pins;
    }

    public void setPins(List<Integer> pins) {
        this.pins = pins;
    }

    public void add(int value) {
        this.pins.add(value);
    }

    public void clear() {
        this.pins.clear();
    }

    public String convertToString() {
        StringBuilder result = new StringBuilder();
        for (int value : this.pins) {
            result.append(value);
        }
        return result.toString();
    }
}
